// const API_BASE_URL = "http://192.168.29.58:7000"; // Change this if needed
const API_BASE_URL = "http://localhost:7000"; // Change this if needed
export default API_BASE_URL;
