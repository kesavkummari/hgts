import datetime
import random
import string
import uuid


import pytz
from cryptography.fernet import Fernet
from sqlalchemy import Column, Integer, String, DateTime, Text, TIMESTAMP, func
from sqlalchemy.orm import Session
from sqlalchemy.orm import declarative_base

from util import KEY

Base = declarative_base()

#################### # User Model ####################
class User(Base):
    __tablename__ = "users"
    __table_args__ = {"schema": "notifications"}

    id = Column(Integer, primary_key=True, index=True)
    uid = Column(String, unique=True, index=True, default=lambda: str(uuid.uuid4()))
    username = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    password = Column(String, nullable=False)
    college_name = Column(String, nullable=False)
    year_of_graduation = Column(Integer, nullable=True)
    current_year = Column(Integer, nullable=True)
    roll_number = Column(String, nullable=True)
    mobile_number = Column(String, nullable=False)
    alternative_mobile_number = Column(String, nullable=True)
    location = Column(String, nullable=False)
    gender = Column(String, nullable=False)

    # Added OTP fields
    otp = Column(String, nullable=True)
    otp_expiry = Column(DateTime, nullable=True, default=lambda: datetime.datetime.now(datetime.timezone.utc))

#################### Notification Model####################
class Notification(Base):
    __tablename__ = "notifications"
    __table_args__ = {"schema": "notifications"}

    id = Column(Integer, primary_key=True, index=True)
    recipient = Column(String, index=True, nullable=False)
    subject = Column(String, nullable=False)
    message = Column(Text, nullable=False)
    created_at = Column(TIMESTAMP, server_default=func.now())


#################User functions################

class UserRepository:
    @staticmethod
    def create_user(db: Session, user: User):
        db.add(user)
        db.commit()
        db.refresh(user)
        return user

    @staticmethod
    def get_user_by_email(db: Session, email: str):
        return db.query(User).filter(User.email == email).first()

    @staticmethod
    def get_user_by_uid(db: Session, uid: str):
        return db.query(User).filter(User.uid == uid).first()

    @staticmethod
    def delete_user(db: Session, email: str):
        user = db.query(User).filter(User.email == email).first()
        if user:
            db.delete(user)
            db.commit()
            return True
        return False

    @staticmethod
    def store_otp(db: Session, email: str):
        """Generate and store a random OTP"""
        user = db.query(User).filter(User.email == email).first()
        if not user:
            return None

        otp = ''.join(random.choices(string.digits, k=6))  # Generate 6-digit OTP
        otp_expiry = datetime.datetime.now(datetime.UTC) + datetime.timedelta(minutes=5)  # OTP expires in 5 min

        user.otp = otp
        user.otp_expiry = otp_expiry
        db.commit()

        return otp  # Return OTP for sending via email/SMS

    @staticmethod
    def verify_otp(db: Session, email: str, otp: str):
        """Check if OTP is valid and not expired"""
        user = db.query(User).filter(User.email == email).first()
        print(user, "user")
        if not user or not user.otp:
            return False, "Invalid OTP."

        if user.otp != otp:
            return False, "Incorrect OTP."
        if datetime.datetime.now(pytz.UTC) > user.otp_expiry:
            return False, "OTP has expired. Please request a new one."

        # Clear OTP after successful verification
        user.otp = None
        user.otp_expiry = None
        db.commit()

        return True, "OTP Verified Successfully!"

    @staticmethod
    def check_user_password(db: Session, email: str, password: str):
        """Verify if the user's password matches the stored password"""
        user = db.query(User).filter(User.email == email).first()
        print(user.email, "userlogindata")  # Debug log for checking user data
        if user:
            # Hash the incoming password and compare it to the stored hash
            fernet = Fernet(KEY)
            decrypted = fernet.decrypt(user.password.encode()).decode()
            if decrypted == password:
                return user
        return None


