from repository import  UserRepository
from util import get_db, TEST_DATA4


def email_login_user(email: str, password: str):
    with next(get_db()) as db:
        # Call the repository method to validate the user
        user = UserRepository.check_user_password(db, email, password)
        print(user, "userlogindata1")
        if user:
            return user  # If user exists and password matches
        return None

def lambda_handler(event, context):
    print(f"context: {context}")
    user = email_login_user(event.get("email"), event.get("password"))
    if not user:
        return {"status_code":400, "message": "Invalid email or password"}
    return {"message": "Login Successfull", "email": user.email}

if __name__ == "__main__":
    event1 = TEST_DATA4
    print(lambda_handler(event1, None))