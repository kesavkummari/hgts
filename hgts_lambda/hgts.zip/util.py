from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# 🔹 SMTP Email Credentials (Use your email and app password)
EMAIL_ADDRESS = "kchemalatha3@gmail.com"  # ✅ Replace with your email
EMAIL_PASSWORD = "ygzz mdbe tbdo wudx"  # ✅ Replace with your App Password
# DATABASE_URL = "postgresql://postgres:Hgts%402025@localhost:5432/postgres"
DATABASE_URL = "postgresql://hgts_usr:Hgts#2025@hgts.cxui6suwakmd.ap-south-2.rds.amazonaws.com:5432/hgts"

KEY = b'8R3hH3Zm0snWHozenNYP6-REdkjWhp0qZ-a3iUhl25E=' # Fernet.generate_key()

########################## database #########################
# PostgreSQL Connection (Update with your credentials)

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ✅ Test PostgreSQL Connection
try:
    with engine.connect() as connection:
        print("✅ Successfully connected to PostgreSQL!")
except Exception as e:
    print("❌ Failed to connect:", e)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()





TEST_DATA1 = {
                "username" : "test_user",
                "email" : "arunkumar03jak1@gmail.com",
                "password" : "user_password",
                "college_name" : "college_name",
                "year_of_graduation" : 2010,
                "current_year" : 2025,
                "roll_number" : "roll_number",
                "mobile_number" : "mobile_number",
                "alternative_mobile_number" : "alternative_mobile_number",
                "location" : "location",
                "gender" : "gender"
            }

TEST_DATA2 = {
        "email":"arunkumar03jak1@gmail.com"
    }

TEST_DATA3={
        "email":"murthy.parupudi@gmail.com",
        "otp":"353841"
    }

TEST_DATA4={
        "email":"arunkumar03jak1@gmail.com",
        "password":"user_password"
    }

TEST_DATA5={
        "uid":"675b1b3f-b91f-42ad-b59a-0c2b4c2954be",
        "subject":"test send notification",
        "message":"this is a test message"
    }