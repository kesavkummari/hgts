from repository import User,  UserRepository

from util import get_db, TEST_DATA2


def delete_user(email):
    with next(get_db()) as db:
        if not UserRepository.get_user_by_email(db, email):
            return "User Doesn't exits"

        user = db.query(User).filter(User.email == email).first()
        try:
            db.delete(user)
            db.commit()
            # db.refresh(user)
        except Exception as e:
            return {"status_code":400, "message":e}
        return {"status_code":200, "message":"user deleted successfully"}

def lambda_handler(event, context):
    print(f"context: {context}")
    response = delete_user(event.get("email"))
    return response

if __name__ == "__main__":
    event1 = TEST_DATA2
    print(lambda_handler(event1, None))