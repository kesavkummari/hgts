import random
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import pytz
from cryptography.fernet import Fernet

from repository import User
from repository import UserRepository


from util import get_db, KEY, TEST_DATA1, EMAIL_ADDRESS, EMAIL_PASSWORD


def send_email_otpV1(email: str, otp: str):
    """Send OTP to email using SMTP"""
    # ✅ Create email message
    subject = "Your OTP Code"
    body = f"Your OTP code is: {otp}\n\nThis code is valid for 5 minutes."
    msg = MIMEMultipart()
    msg["From"] = EMAIL_ADDRESS
    msg["To"] = email
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    # ✅ Connect to SMTP server (Gmail)
    server = smtplib.SMTP("smtp1.gmail.com", 587)
    server.starttls()  # Secure connection
    server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Login to email
    server.sendmail(EMAIL_ADDRESS, email, msg.as_string())  # Send email
    server.quit()  # Close connection

    return {
                'statusCode': 200,
                'message': f"✅ OTP Sent to {email}: {otp}"
            }



def create_user(user_data: dict):
    """Create a new user and generate an OTP"""
    with next(get_db()) as db:
        # Database query for user exists
        if UserRepository.get_user_by_email(db, user_data["email"]):
            return "User Already exits"

        # ✅ Hash the password
        # print("key",KEY)
        cipher = Fernet(KEY)
        encrypted = cipher.encrypt(user_data["password"].encode())
        # decrypted = cipher.decrypt(encrypted).decode()
        # print("decrypted",decrypted)
        # pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
        # hashed_password = pwd_context.hash(user_data["password"])

        hashed_password = encrypted
        # print("hashed_password",hashed_password)

        # ✅ Generate OTP and Expiry at the time of user creation
        otp = str(random.randint(100000, 999999))  # Generate 6-digit OTP
        otp_expiry = datetime.now(pytz.UTC) + timedelta(minutes=5)  # Use timezone-aware UTC datetime
        # print("otp_expiry",otp_expiry)

        new_user = User(
            username=user_data["username"],
            email=user_data["email"],
            password=hashed_password.decode(),
            college_name=user_data["college_name"],
            year_of_graduation=user_data.get("year_of_graduation"),
            current_year=user_data.get("current_year"),
            roll_number=user_data.get("roll_number"),
            mobile_number=user_data["mobile_number"],
            alternative_mobile_number=user_data.get("alternative_mobile_number"),
            location=user_data["location"],
            gender=None if user_data["gender"] == "Select Gender" else user_data["gender"],
            otp=otp,  # ✅ Store OTP
            otp_expiry=otp_expiry,  # ✅ Store expiry time
        )

        user = UserRepository.create_user(db, new_user)

        # ✅ Send OTP via email after creating the user
        send_email_otpV1(user.email, otp)

        return user.email

def lambda_handler(event, context):
    print(f"context: {context}")
    return create_user(event)

if __name__ == "__main__":
    user_data1 = TEST_DATA1
    print(lambda_handler(user_data1,None))