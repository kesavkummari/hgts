import smtplib  # ✅ SMTP for sending emails


from sqlalchemy.orm import Session
from repository import Notification, UserRepository
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from util import EMAIL_ADDRESS, EMAIL_PASSWORD, get_db, TEST_DATA5


def send_email(email:str, subject:str, message:str):
    try:
        # ✅ Create email message
        subject = subject
        body = message
        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        # ✅ Connect to SMTP server (Gmail)
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()  # Secure connection
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Login to email
        server.sendmail(EMAIL_ADDRESS, email, msg.as_string())  # Send email
        server.quit()  # Close connection

        return {
                    'statusCode': 200,
                    'message': f"✅ Email Sent Successfully"
                }

    except Exception as e:
        return {
                    'statusCode': 300,
                    'message': f"❌ Failed to send email: {e}"
                }

def create_notification(db: Session, notification: Notification):
    db.add(notification)
    db.commit()
    return notification

def send_notification(uid: str, subject: str, message: str):
    with next(get_db()) as db:
        user = UserRepository.get_user_by_uid(db, uid)
        print("user->",user.email)
        if not user:
            return None

        new_notification = Notification(
            recipient=user.email,
            subject=subject,
            message=message
        )

        send_email(user.email, subject, message)

        return create_notification(db, new_notification)

def lambda_handler(event, context):
    send_notification(event.get("uid"), event.get("subject"), event.get("message"))

if __name__ == "__main__":
    event1 = TEST_DATA5
    lambda_handler(event1,None)