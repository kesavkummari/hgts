from repository import UserRepository
from datetime import datetime, timezone

from util import get_db, TEST_DATA3


def verify_otp(email: str, otp: str):
    with next(get_db()) as db:
        # print(f"🔍 Received Email: {email}, OTP: {otp}")
        user = UserRepository.get_user_by_email(db, email)
        # print(user, "Fetched User from DB")

        if not user:
            # print("User not found")
            return {"status_code":400, "message":"User not found"}
        # print(f"Stored OTP: {user.otp}, Received OTP: {otp}")

        # ✅ Ensure `otp_expiry` is timezone-aware before comparing
        if user.otp_expiry.tzinfo is None:
            user.otp_expiry = user.otp_expiry.replace(tzinfo=timezone.utc)

        if user.otp != otp or datetime.now(timezone.utc) > user.otp_expiry:
            # if user.otp != otp or datetime.now() > user.otp_expiry.replace(tzinfo=None):

            # print("OTP does not match or OTP Expired")
            return {
                "status_code":402, "message":"Invalid OTP or OTP expired"
            }

        # ✅ OTP verification successful
        user.otp = None
        user.otp_expiry = None
        db.commit()
        db.refresh(user)
        # print("✅ OTP Verified Successfully!")
        return {"status_code":200, "message": "OTP Verified Successfully!", "success": True}

def lambda_handler(event, context):
    print(f"context {context}")
    response = verify_otp(event.get("email"), event.get("otp"))
    return response

if __name__ == "__main__":
    event1=TEST_DATA3
    print(lambda_handler(event1,None))