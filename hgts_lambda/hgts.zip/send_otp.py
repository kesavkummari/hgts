
import random
import pytz  # ✅ Ensure datetime is timezone-aware

from datetime import datetime,  timedelta
from repository import UserRepository
from send_email_otp import send_email_otp
from util import get_db


def send_otp(email: str):
    """Generate and send OTP"""
    with next(get_db()) as db:
        user = UserRepository.get_user_by_email(db, email)
        print(f"user.id : {user.id}")
        if not user:
            return None

        # ✅ Generate OTP and expiry
        otp = str(random.randint(100000, 999999))
        expiry_time = datetime.now(pytz.UTC) + timedelta(minutes=5)

        user.otp = otp
        user.otp_expiry = expiry_time

        db.commit()

        db.refresh(user)


        # ✅ Send OTP via email
        send_email_otp(user.email, otp)

        print(f"✅ OTP Sent to {email}: {otp}")

        return otp

if __name__=="__main__":
    send_otp("arunkumar03jak1@gmail.com")