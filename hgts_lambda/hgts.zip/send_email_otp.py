
import smtplib  # ✅ SMTP for sending emails
from sys import exception

from util import EMAIL_ADDRESS, EMAIL_PASSWORD
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_email_otp(email: str, otp: str):
    """Send OTP to email using SMTP"""
    try:
        # ✅ Create email message
        subject = "Your OTP Code"
        body = f"Your OTP code is: {otp}\n\nThis code is valid for 5 minutes."
        msg = MIMEMultipart()
        msg["From"] = EMAIL_ADDRESS
        msg["To"] = email
        msg["Subject"] = subject
        msg.attach(MIMEText(body, "plain"))

        # ✅ Connect to SMTP server (Gmail)
        server = smtplib.SMTP("smtp1.gmail.com", 587)
        server.starttls()  # Secure connection
        server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)  # Login to email
        server.sendmail(EMAIL_ADDRESS, email, msg.as_string())  # Send email
        server.quit()  # Close connection

        return {
                    'statusCode': 200,
                    'message': f"✅ OTP Sent to {email}: {otp}"
                }

    except Exception as e:
        return {
                    'statusCode': 300,
                    'message': f"❌ Failed to send OTP: {e}"
                }

def lambda_handler(event, context):
    # {"email":"aaa", "otp""1234"}
    print(context)
    return send_email_otp(event.get("email"), event.get("otp"))

if __name__ == "__main__":
    event1 = {"email": "arunkumar03jak1@gmail.com", "otp": "234123"}
    response = send_email_otp(event1.get("email"), event1.get("otp"))
    print(response)